package com.organizo.app.viewmodel

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

fun colName(index: Int): String {
    var n = index + 1
    val sb = StringBuilder()
    while (n > 0) {
        val r = (n - 1) % 26
        sb.insert(0, 'A' + r)
        n = (n - 1) / 26
    }
    return sb.toString()
}

private fun esc(s: String): String {
    val sb = StringBuilder()
    for (ch in s) {
        if (ch == '&') sb.append("&amp;")
        else if (ch == '<') sb.append("&lt;")
        else if (ch == '>') sb.append("&gt;")
        else if (ch == '"') sb.append("&quot;")
        else if (ch.code < 32 && ch != '\n' && ch != '\t' && ch != '\r') { /* skip invalid XML char */ }
        else sb.append(ch)
    }
    return sb.toString()
}

private val numberRegex = Regex("^-?(0|[1-9][0-9]*)(\\.[0-9]+)?$")

fun toCsv(rows: List<List<String>>): String =
    "\uFEFF" + rows.joinToString("\n") { r ->
        r.joinToString(",") { f ->
            if (f.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
                "\"" + f.replace("\"", "\"\"") + "\""
            } else f
        }
    }

/** Writes a minimal, valid .xlsx (one sheet, values only) without any external library. */
fun writeXlsx(out: OutputStream, rows: List<List<String>>, ev: SheetEvaluator? = null) {
    ZipOutputStream(out).use { z ->
        fun put(name: String, content: String) {
            z.putNextEntry(ZipEntry(name))
            z.write(content.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        put(
            "[Content_Types].xml",
            head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>"
        )
        put(
            "xl/workbook.xml",
            head + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        )
        put(
            "xl/_rels/workbook.xml.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "</Relationships>"
        )
        val sb = StringBuilder()
        sb.append(head)
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { i, row ->
            sb.append("<row r=\"").append(i + 1).append("\">")
            row.forEachIndexed { c, v ->
                if (v.isNotEmpty()) {
                    val ref = colName(c) + (i + 1)
                    if (ev != null && v.length > 1 && v[0] == '=') {
                        val cv = ev.cellValue(i, c)
                        val f = esc(v.substring(1))
                        sb.append("<c r=\"").append(ref).append("\"")
                        if (cv is Double) {
                            sb.append("><f>").append(f).append("</f><v>").append(formatNumber(cv)).append("</v></c>")
                        } else if (cv is Boolean) {
                            sb.append(" t=\"b\"><f>").append(f).append("</f><v>").append(if (cv) "1" else "0").append("</v></c>")
                        } else if (cv is FErr) {
                            sb.append(" t=\"e\"><f>").append(f).append("</f><v>").append(esc(cv.code)).append("</v></c>")
                        } else {
                            sb.append(" t=\"str\"><f>").append(f).append("</f><v>").append(esc(ev.format(cv))).append("</v></c>")
                        }
                    } else if (numberRegex.matches(v)) {
                        sb.append("<c r=\"").append(ref).append("\"><v>").append(v).append("</v></c>")
                    } else {
                        sb.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                            .append(esc(v)).append("</t></is></c>")
                    }
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        put("xl/worksheets/sheet1.xml", sb.toString())
    }
}

data class DocPara(
    val text: String,
    val style: Int = 0,        // 0 normal, 1 heading 1, 2 heading 2
    val bold: Boolean = false,
    val italic: Boolean = false,
    val bullet: Boolean = false,
    val align: Int = 0         // 0 left, 1 center, 2 right
)

/** Writes a simple, valid .docx (paragraph-level formatting) without any external library. */
fun writeDocx(out: OutputStream, paras: List<DocPara>) {
    ZipOutputStream(out).use { z ->
        fun put(name: String, content: String) {
            z.putNextEntry(ZipEntry(name))
            z.write(content.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        val w = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\""
        put(
            "[Content_Types].xml",
            head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
                "</Types>"
        )
        put(
            "_rels/.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>"
        )
        put(
            "word/_rels/document.xml.rels",
            head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>"
        )
        put(
            "word/styles.xml",
            head + "<w:styles $w>" +
                "<w:docDefaults><w:rPrDefault><w:rPr><w:sz w:val=\"24\"/></w:rPr></w:rPrDefault></w:docDefaults>" +
                "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style>" +
                "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/>" +
                "<w:pPr><w:keepNext/><w:spacing w:before=\"240\" w:after=\"120\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"36\"/></w:rPr></w:style>" +
                "<w:style w:type=\"paragraph\" w:styleId=\"Heading2\"><w:name w:val=\"heading 2\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/>" +
                "<w:pPr><w:keepNext/><w:spacing w:before=\"200\" w:after=\"100\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"30\"/></w:rPr></w:style>" +
                "</w:styles>"
        )
        val sb = StringBuilder()
        sb.append(head).append("<w:document $w><w:body>")
        for (p in paras) {
            sb.append("<w:p>")
            val ppr = StringBuilder()
            if (p.style == 1) ppr.append("<w:pStyle w:val=\"Heading1\"/>")
            else if (p.style == 2) ppr.append("<w:pStyle w:val=\"Heading2\"/>")
            if (p.align == 1) ppr.append("<w:jc w:val=\"center\"/>")
            else if (p.align == 2) ppr.append("<w:jc w:val=\"right\"/>")
            if (ppr.isNotEmpty()) sb.append("<w:pPr>").append(ppr).append("</w:pPr>")
            val rpr = (if (p.bold) "<w:b/>" else "") + (if (p.italic) "<w:i/>" else "")
            val lines = ((if (p.bullet) "• " else "") + p.text).split("\n")
            sb.append("<w:r>")
            if (rpr.isNotEmpty()) sb.append("<w:rPr>").append(rpr).append("</w:rPr>")
            lines.forEachIndexed { idx, ln ->
                if (idx > 0) sb.append("<w:br/>")
                sb.append("<w:t xml:space=\"preserve\">").append(esc(ln)).append("</w:t>")
            }
            sb.append("</w:r></w:p>")
        }
        sb.append("<w:sectPr/></w:body></w:document>")
        put("word/document.xml", sb.toString())
    }
}
