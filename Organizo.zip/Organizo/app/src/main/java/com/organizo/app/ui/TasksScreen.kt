package com.organizo.app.ui

import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.organizo.app.data.Task
import com.organizo.app.viewmodel.TasksViewModel
import java.time.LocalDate

private fun tasksAsText(tasks: List<Task>): String {
    val open = tasks.filter { it.status != 2 }
    if (open.isEmpty()) return "No pending tasks."
    return open.joinToString("\n") { t ->
        "• " + t.title +
            " [" + PriorityLabels.getOrElse(t.priority) { "Medium" } + ", " + StatusLabels.getOrElse(t.status) { "Pending" } + "]" +
            (t.dueDate?.let { " – due " + fmtDay(it) } ?: "")
    }
}

@Composable
fun TasksScreen(vm: TasksViewModel = viewModel()) {
    val ctx = LocalContext.current
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val overdue by vm.overdueCount.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableIntStateOf(0) }   // 0 all, 1 pending, 2 in progress, 3 completed
    var catFilter by rememberSaveable { mutableStateOf("") }
    var dialogOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var toDelete by remember { mutableStateOf<Task?>(null) }

    val shown = tasks.filter { t ->
        (filter == 0 || t.status == filter - 1) && (catFilter.isEmpty() || t.category == catFilter)
    }

    Scaffold(
        topBar = {
            OrgTopBar("Tasks", actions = {
                IconButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "My tasks")
                        putExtra(Intent.EXTRA_TEXT, tasksAsText(tasks))
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share pending tasks"))
                }) { Icon(Icons.Filled.Share, "Share pending tasks") }
            })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editing = null; dialogOpen = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) { Icon(Icons.Filled.Add, "Add task") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (overdue > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 10.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(Modifier.padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "$overdue unfinished task(s) from earlier days",
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = { vm.carryForward() }) { Text("Carry forward") }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Pending", "In Progress", "Completed").forEachIndexed { i, label ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = catFilter.isEmpty(), onClick = { catFilter = "" }, label = { Text("All categories") })
                Categories.forEach { c ->
                    FilterChip(selected = catFilter == c, onClick = { catFilter = if (catFilter == c) "" else c }, label = { Text(c) })
                }
            }
            if (shown.isEmpty()) {
                EmptyState(
                    Icons.Filled.TaskAlt,
                    if (tasks.isEmpty()) "No tasks yet" else "Nothing here",
                    if (tasks.isEmpty()) "Tap + to add your first task." else "No tasks match these filters."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { t ->
                        TaskCard(
                            t,
                            onToggle = { vm.toggle(t) },
                            onCycle = { vm.cycleStatus(t) },
                            onEdit = { editing = t; dialogOpen = true },
                            onDelete = { toDelete = t }
                        )
                    }
                }
            }
        }
    }

    if (dialogOpen) {
        TaskDialog(
            initial = editing,
            onSave = { vm.save(it); dialogOpen = false },
            onDismiss = { dialogOpen = false }
        )
    }
    toDelete?.let { t ->
        ConfirmDialog(
            title = "Delete task?",
            message = "\"${t.title}\" will be permanently deleted.",
            onConfirm = { vm.delete(t); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
}

@Composable
private fun TaskCard(t: Task, onToggle: () -> Unit, onCycle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val done = t.status == 2
    val overdue = !done && t.dueDate != null && t.dueDate < LocalDate.now().toEpochDay()
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = orgCardColors(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (done) TextDecoration.LineThrough else null,
                    color = if (done) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (t.description.isNotBlank()) {
                    Text(
                        t.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(StatusLabels.getOrElse(t.status) { "Pending" }, statusColor(t.status), onClick = onCycle)
                    PriorityBadge(t.priority)
                    if (t.category.isNotEmpty()) Pill(t.category, MaterialTheme.colorScheme.primary)
                }
                if (t.dueDate != null || t.carried > 0) {
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (t.dueDate != null) {
                            Text(
                                (if (overdue) "Overdue · " else "Due ") + fmtDay(t.dueDate),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (t.carried > 0) {
                            Text(
                                "Carried forward ${t.carried}×",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit task") }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete task") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TaskDialog(initial: Task?, onSave: (Task) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var priority by remember { mutableIntStateOf(initial?.priority ?: 1) }
    var status by remember { mutableIntStateOf(initial?.status ?: 0) }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var due by remember { mutableStateOf(initial?.dueDate) }
    var picker by remember { mutableStateOf(false) }
    var titleError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New task" else "Edit task") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; titleError = false },
                    label = { Text("Title") },
                    isError = titleError,
                    supportingText = { if (titleError) Text("Please enter a title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description (optional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Status", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusLabels.forEachIndexed { i, label ->
                        FilterChip(selected = status == i, onClick = { status = i }, label = { Text(label) })
                    }
                }
                Text("Priority", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PriorityLabels.forEachIndexed { i, label ->
                        FilterChip(selected = priority == i, onClick = { priority = i }, label = { Text(label) })
                    }
                }
                Text("Category", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Categories.forEach { c ->
                        FilterChip(
                            selected = category == c,
                            onClick = { category = if (category == c) "" else c },
                            label = { Text(c) }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { picker = true }) {
                        Icon(Icons.Filled.CalendarMonth, null)
                        Spacer(Modifier.width(8.dp))
                        Text(due?.let { fmtDay(it) } ?: "Set due date")
                    }
                    if (due != null) {
                        IconButton(onClick = { due = null }) { Icon(Icons.Filled.Close, "Clear due date") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isBlank()) {
                    titleError = true
                } else {
                    onSave(
                        (initial ?: Task(title = "")).copy(
                            title = title.trim(),
                            description = desc.trim(),
                            priority = priority,
                            status = status,
                            category = category,
                            dueDate = due
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )

    if (picker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = due?.let { it * 86_400_000L })
        DatePickerDialog(
            onDismissRequest = { picker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { due = Math.floorDiv(it, 86_400_000L) }
                    picker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}
