package com.organizo.app.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.organizo.app.data.Note
import com.organizo.app.data.OrganizoDb
import com.organizo.app.data.Task
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.io.IOException

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val db = OrganizoDb.get(app)
    val noteCount: StateFlow<Int> =
        db.noteDao().count().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val pendingTasks: StateFlow<Int> =
        db.taskDao().pendingCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
}

class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = OrganizoDb.get(app).noteDao()
    val query = MutableStateFlow("")
    val categoryFilter = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val notes: StateFlow<List<Note>> = combine(query, categoryFilter) { q, c -> q to c }
        .flatMapLatest { pair ->
            dao.search(pair.first.trim()).map { list ->
                if (pair.second.isEmpty()) list else list.filter { it.category == pair.second }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(q: String) {
        query.value = q
    }

    fun setCategory(c: String) {
        categoryFilter.value = c
    }

    fun togglePin(n: Note) {
        viewModelScope.launch { dao.setPinned(n.id, !n.pinned) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { withContext(NonCancellable) { dao.deleteById(id) } }
    }
}

/** Editor with debounced auto-save: every edit is written to Room 0.6s after you stop typing. */
class NoteEditorViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = OrganizoDb.get(app).noteDao()
    private var noteId = 0L
    private var started = false
    private var dirty = false
    private var discarded = false
    private var saveJob: Job? = null

    var title by mutableStateOf("")
        private set
    var content by mutableStateOf("")
        private set
    var pinned by mutableStateOf(false)
        private set
    var color by mutableIntStateOf(0)
        private set
    var category by mutableStateOf("")
        private set
    var status by mutableStateOf("")
        private set

    fun load(id: Long) {
        if (started) return
        started = true
        noteId = id
        if (id > 0) {
            viewModelScope.launch {
                dao.get(id)?.let {
                    title = it.title
                    content = it.content
                    pinned = it.pinned
                    color = it.color
                    category = it.category
                }
            }
        }
    }

    fun onTitle(v: String) {
        title = v
        scheduleSave()
    }

    fun onContent(v: String) {
        content = v
        scheduleSave()
    }

    fun togglePin() {
        pinned = !pinned
        scheduleSave()
    }

    fun setColor(i: Int) {
        color = i
        scheduleSave()
    }

    fun toggleCategory(c: String) {
        category = if (category == c) "" else c
        scheduleSave()
    }

    private fun scheduleSave() {
        dirty = true
        status = "Saving…"
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(600)
            withContext(NonCancellable) { persist() }
        }
    }

    private suspend fun persist() {
        if (!dirty || discarded) return
        dirty = false
        if (title.isBlank() && content.isBlank() && noteId == 0L) {
            status = ""
            return
        }
        val n = Note(
            id = noteId, title = title, content = content, pinned = pinned,
            updatedAt = System.currentTimeMillis(), color = color, category = category
        )
        if (noteId == 0L) noteId = dao.insert(n) else dao.update(n)
        status = "Saved"
    }

    fun flush() {
        saveJob?.cancel()
        viewModelScope.launch { withContext(NonCancellable) { persist() } }
    }

    fun delete() {
        discarded = true
        saveJob?.cancel()
        val id = noteId
        if (id > 0) viewModelScope.launch { withContext(NonCancellable) { dao.deleteById(id) } }
    }
}

class TasksViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = OrganizoDb.get(app).taskDao()
    val tasks: StateFlow<List<Task>> =
        dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val overdueCount: StateFlow<Int> =
        dao.overdueCount(LocalDate.now().toEpochDay())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun save(t: Task) {
        val fixed = t.copy(completed = t.status == 2)
        viewModelScope.launch { if (fixed.id == 0L) dao.insert(fixed) else dao.update(fixed) }
    }

    /** Check box: Completed <-> Pending. */
    fun toggle(t: Task) = save(t.copy(status = if (t.status == 2) 0 else 2))

    /** Tap the status badge: Pending -> In Progress -> Completed -> Pending. */
    fun cycleStatus(t: Task) = save(t.copy(status = (t.status + 1) % 3))

    fun carryForward() {
        viewModelScope.launch { dao.carryForward(LocalDate.now().toEpochDay()) }
    }

    fun delete(t: Task) {
        viewModelScope.launch { dao.deleteById(t.id) }
    }
}

class PdfViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app
    private val mutex = Mutex()
    private var renderer: PdfRenderer? = null

    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var fileName by mutableStateOf("")
        private set
    var pageCount by mutableIntStateOf(0)
        private set
    var docId by mutableIntStateOf(0)
        private set

    fun open(uri: Uri) {
        viewModelScope.launch {
            loading = true
            error = null
            pageCount = 0
            try {
                val name = withContext(Dispatchers.IO) { displayName(ctx, uri) }
                var pages = 0
                mutex.withLock {
                    withContext(Dispatchers.IO) {
                        renderer?.close()
                        renderer = null
                        val f = File(ctx.cacheDir, "current.pdf")
                        val input = ctx.contentResolver.openInputStream(uri)
                            ?: throw IOException("Unable to open the selected file.")
                        input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                        val r = PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY))
                        renderer = r
                        pages = r.pageCount
                    }
                }
                fileName = name
                pageCount = pages
                docId++
            } catch (e: SecurityException) {
                error = "Password-protected PDFs are not supported."
            } catch (e: Exception) {
                error = "Could not open this PDF. The file may be damaged or is not a valid PDF."
            }
            loading = false
        }
    }

    suspend fun render(index: Int, widthPx: Int): Bitmap? = mutex.withLock {
        withContext(Dispatchers.IO) {
            val r = renderer ?: return@withContext null
            if (index !in 0 until r.pageCount) return@withContext null
            try {
                r.openPage(index).use { page ->
                    val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    override fun onCleared() {
        try {
            renderer?.close()
        } catch (_: Exception) {
        }
        renderer = null
    }
}

sealed interface DocContent {
    data class Table(val rows: List<List<String>>) : DocContent
    data class TextDoc(val paragraphs: List<DocPara>) : DocContent
}

sealed interface DocState {
    object Idle : DocState
    object Loading : DocState
    data class Error(val message: String) : DocState
    data class Loaded(val name: String, val content: DocContent, val note: String?) : DocState
}

class DocsViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app

    var state by mutableStateOf<DocState>(DocState.Idle)
        private set
    var rows by mutableStateOf<List<List<String>>>(emptyList())
        private set
    var paras by mutableStateOf<List<DocPara>>(emptyList())
        private set
    var dirty by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    fun clearMessage() {
        message = null
    }

    fun open(uri: Uri) {
        state = DocState.Loading
        viewModelScope.launch {
            val result: DocState = try {
                withContext(Dispatchers.IO) { load(uri) }
            } catch (e: DocException) {
                DocState.Error(e.message ?: "Could not open this file.")
            } catch (e: Exception) {
                DocState.Error("Could not read this file. It may be damaged, password-protected or in an unsupported format.")
            }
            if (result is DocState.Loaded) {
                val c = result.content
                if (c is DocContent.Table) {
                    rows = c.rows
                    dirty = false
                } else if (c is DocContent.TextDoc) {
                    paras = c.paragraphs
                    dirty = false
                }
            }
            state = result
        }
    }

    fun newSheet() {
        rows = List(30) { List(10) { "" } }
        dirty = false
        state = DocState.Loaded("New spreadsheet.xlsx", DocContent.Table(rows), null)
    }

    fun newDocument() {
        paras = listOf(DocPara(""))
        dirty = false
        state = DocState.Loaded("New document.docx", DocContent.TextDoc(paras), null)
    }

    // ---- spreadsheet editing (a cell may hold a formula such as =SUM(A1:A5)) ----
    fun setCell(r: Int, c: Int, value: String) {
        if (r !in rows.indices) return
        val list = rows.toMutableList()
        val row = list[r].toMutableList()
        while (row.size <= c) row.add("")
        row[c] = value
        list[r] = row
        rows = list
        dirty = true
    }

    fun addRow(after: Int) {
        val cols = (rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
        val list = rows.toMutableList()
        list.add((after + 1).coerceIn(0, list.size), List(cols) { "" })
        rows = list
        dirty = true
    }

    fun addColumn(after: Int) {
        rows = rows.map { r ->
            val m = r.toMutableList()
            while (m.size <= after) m.add("")
            m.add(after + 1, "")
            m
        }
        dirty = true
    }

    fun deleteRow(r: Int) {
        if (rows.size > 1 && r in rows.indices) {
            rows = rows.filterIndexed { i, _ -> i != r }
            dirty = true
        }
    }

    fun deleteColumn(c: Int) {
        val cols = rows.maxOfOrNull { it.size } ?: 0
        if (cols > 1) {
            rows = rows.map { r -> if (c < r.size) r.filterIndexed { i, _ -> i != c } else r }
            dirty = true
        }
    }

    // ---- word-processor editing (paragraph level) ----
    fun updatePara(i: Int, change: (DocPara) -> DocPara) {
        if (i !in paras.indices) return
        val list = paras.toMutableList()
        list[i] = change(list[i])
        paras = list
        dirty = true
    }

    fun setParaText(i: Int, text: String) = updatePara(i) { it.copy(text = text) }

    fun addPara(after: Int) {
        val list = paras.toMutableList()
        list.add((after + 1).coerceIn(0, list.size), DocPara(""))
        paras = list
        dirty = true
    }

    fun deletePara(i: Int) {
        if (paras.size > 1 && i in paras.indices) {
            paras = paras.filterIndexed { idx, _ -> idx != i }
            dirty = true
        }
    }

    fun suggestedName(ext: String): String {
        val n = (state as? DocState.Loaded)?.name ?: "document"
        return n.substringBeforeLast('.') + "_edited." + ext
    }

    private fun saveWith(uri: Uri, block: (java.io.OutputStream) -> Unit) {
        viewModelScope.launch {
            message = try {
                withContext(Dispatchers.IO) {
                    val out = ctx.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Unable to create the file.")
                    out.use(block)
                }
                dirty = false
                "Saved successfully"
            } catch (e: Exception) {
                "Could not save the file."
            }
        }
    }

    fun save(uri: Uri, xlsx: Boolean) {
        val snapshot = rows
        saveWith(uri) { o ->
            val ev = SheetEvaluator(snapshot)
            if (xlsx) {
                writeXlsx(o, snapshot, ev)
            } else {
                val shown = snapshot.mapIndexed { r, row -> row.indices.map { c -> ev.display(r, c) } }
                o.write(toCsv(shown).toByteArray(Charsets.UTF_8))
            }
        }
    }

    fun saveDocx(uri: Uri) {
        val snapshot = paras
        saveWith(uri) { o -> writeDocx(o, snapshot) }
    }

    private fun load(uri: Uri): DocState {
        val name = displayName(ctx, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "csv", "tsv" -> tableState(name, parseCsv(readText(ctx, uri), MAX_ROWS + 1))
            "xlsx" -> tableState(name, parseXlsx(ctx, uri, MAX_ROWS + 1))
            "docx" -> {
                val list = parseDocxRich(ctx, uri, MAX_ROWS + 1)
                if (list.isEmpty()) throw DocException("This document appears to be empty.")
                val cut = list.size > MAX_ROWS
                DocState.Loaded(name, DocContent.TextDoc(list.take(MAX_ROWS)), if (cut) "Showing the first $MAX_ROWS paragraphs. A saved copy will include only these." else null)
            }
            "txt" -> {
                val lines = readText(ctx, uri).lines()
                val cut = lines.size > MAX_ROWS
                DocState.Loaded(name, DocContent.TextDoc(lines.take(MAX_ROWS).map { DocPara(it) }), if (cut) "Showing the first $MAX_ROWS lines." else null)
            }
            "xls", "doc" -> throw DocException(
                "Old .$ext files are not supported. Open it in Excel/Word, save it as .xlsx/.docx, then try again."
            )
            else -> throw DocException("Unsupported file type. Please choose a .csv, .xlsx or .docx file.")
        }
    }

    private fun tableState(name: String, rows: List<List<String>>): DocState {
        if (rows.isEmpty()) throw DocException("This file appears to be empty.")
        val cut = rows.size > MAX_ROWS
        val note = if (cut) "Showing the first $MAX_ROWS rows. A saved copy will include only these rows." else null
        return DocState.Loaded(name, DocContent.Table(rows.take(MAX_ROWS)), note)
    }
}

/** Backup / restore of all notes and tasks as one JSON file (pick Google Drive in the file picker for a cloud copy). */
class BackupViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app
    private val db = OrganizoDb.get(app)

    var message by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set

    fun clearMessage() {
        message = null
    }

    fun export(uri: Uri) {
        viewModelScope.launch {
            busy = true
            message = try {
                val counts = withContext(Dispatchers.IO) {
                    val notes = db.noteDao().snapshot()
                    val tasks = db.taskDao().snapshot()
                    val root = JSONObject()
                    root.put("app", "Organizo")
                    root.put("version", 1)
                    val na = JSONArray()
                    for (n in notes) {
                        val o = JSONObject()
                        o.put("id", n.id)
                        o.put("title", n.title)
                        o.put("content", n.content)
                        o.put("pinned", n.pinned)
                        o.put("updatedAt", n.updatedAt)
                        o.put("color", n.color)
                        o.put("category", n.category)
                        na.put(o)
                    }
                    val ta = JSONArray()
                    for (t in tasks) {
                        val o = JSONObject()
                        o.put("id", t.id)
                        o.put("title", t.title)
                        o.put("description", t.description)
                        o.put("priority", t.priority)
                        o.put("dueDate", t.dueDate ?: JSONObject.NULL)
                        o.put("completed", t.completed)
                        o.put("status", t.status)
                        o.put("category", t.category)
                        o.put("carried", t.carried)
                        ta.put(o)
                    }
                    root.put("notes", na)
                    root.put("tasks", ta)
                    val out = ctx.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Unable to create the file.")
                    out.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
                    notes.size to tasks.size
                }
                "Backup saved: ${counts.first} notes, ${counts.second} tasks"
            } catch (e: Exception) {
                "Backup failed. Please try another location."
            }
            busy = false
        }
    }

    fun import(uri: Uri) {
        viewModelScope.launch {
            busy = true
            message = try {
                val counts = withContext(Dispatchers.IO) {
                    val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IOException("Unable to open the file.")
                    val root = JSONObject(text)
                    if (root.optString("app") != "Organizo") throw IOException("Not an Organizo backup.")
                    val na = root.optJSONArray("notes") ?: JSONArray()
                    val ta = root.optJSONArray("tasks") ?: JSONArray()
                    val notes = (0 until na.length()).map { i ->
                        val o = na.getJSONObject(i)
                        Note(
                            id = o.optLong("id", 0),
                            title = o.optString("title"),
                            content = o.optString("content"),
                            pinned = o.optBoolean("pinned"),
                            updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                            color = o.optInt("color"),
                            category = o.optString("category")
                        )
                    }
                    val tasks = (0 until ta.length()).map { i ->
                        val o = ta.getJSONObject(i)
                        Task(
                            id = o.optLong("id", 0),
                            title = o.optString("title"),
                            description = o.optString("description"),
                            priority = o.optInt("priority", 1),
                            dueDate = if (o.isNull("dueDate")) null else o.optLong("dueDate"),
                            completed = o.optBoolean("completed"),
                            status = o.optInt("status"),
                            category = o.optString("category"),
                            carried = o.optInt("carried")
                        )
                    }
                    db.withTransaction {
                        db.noteDao().deleteAll()
                        db.taskDao().deleteAll()
                        db.noteDao().insertAll(notes)
                        db.taskDao().insertAll(tasks)
                    }
                    notes.size to tasks.size
                }
                "Restored ${counts.first} notes and ${counts.second} tasks"
            } catch (e: Exception) {
                "Restore failed. Please choose a valid Organizo backup file."
            }
            busy = false
        }
    }
}
