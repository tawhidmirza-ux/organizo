package com.organizo.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.organizo.app.data.SettingsStore
import com.organizo.app.ui.OrganizoApp
import com.organizo.app.ui.PendingOpen
import com.organizo.app.ui.theme.OrganizoTheme
import com.organizo.app.viewmodel.displayName

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIncoming(intent)
        val store = SettingsStore.get(this)
        setContent {
            val mode by store.mode.collectAsState()
            val dark = when (mode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            DisposableEffect(dark) {
                val transparent = android.graphics.Color.TRANSPARENT
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.dark(transparent),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(transparent)
                    else SystemBarStyle.light(transparent, transparent)
                )
                onDispose { }
            }
            OrganizoTheme(dark) { OrganizoApp() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
            else -> null
        } ?: return
        val type = i.type ?: contentResolver.getType(uri) ?: ""
        val name = try { displayName(this, uri).lowercase() } catch (e: Exception) { "" }
        val isPdf = type == "application/pdf" || name.endsWith(".pdf")
        PendingOpen.kind = if (isPdf) "pdf" else "docs"
        PendingOpen.uri = uri
    }
}
