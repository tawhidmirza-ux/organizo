package com.organizo.app.ui

import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.organizo.app.viewmodel.DocContent
import com.organizo.app.viewmodel.DocState
import com.organizo.app.viewmodel.DocsViewModel
import com.organizo.app.viewmodel.SheetEvaluator
import com.organizo.app.viewmodel.colName

private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
private const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocsScreen(
    onBack: () -> Unit,
    vm: DocsViewModel = viewModel(viewModelStoreOwner = LocalContext.current as ComponentActivity)
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.open(uri)
    }
    val saveXlsx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(XLSX_MIME)) { uri ->
        if (uri != null) vm.save(uri, true)
    }
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) vm.save(uri, false)
    }
    val saveDocx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(DOCX_MIME)) { uri ->
        if (uri != null) vm.saveDocx(uri)
    }
    val openDoc = { picker.launch(arrayOf("*/*")) }
    val st = vm.state
    val snack = remember { SnackbarHostState() }
    var saveMenu by remember { mutableStateOf(false) }
    var newMenu by remember { mutableStateOf(false) }

    val pending = PendingOpen.uri
    LaunchedEffect(pending) {
        if (pending != null && PendingOpen.kind != "pdf") {
            vm.open(pending)
            PendingOpen.uri = null
        }
    }
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snack.showSnackbar(m)
            vm.clearMessage()
        }
    }

    val content = (st as? DocState.Loaded)?.content
    val isTable = content is DocContent.Table
    val isText = content is DocContent.TextDoc

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            OrgTopBar(
                title = (if (st is DocState.Loaded) st.name else "Documents") + (if (vm.dirty) " •" else ""),
                onBack = onBack,
                actions = {
                    if (isTable || isText) {
                        Box {
                            IconButton(onClick = { saveMenu = true }) { Icon(Icons.Filled.Save, "Save a copy") }
                            DropdownMenu(expanded = saveMenu, onDismissRequest = { saveMenu = false }) {
                                if (isTable) {
                                    DropdownMenuItem(
                                        text = { Text("Save as Excel (.xlsx)") },
                                        onClick = { saveMenu = false; saveXlsx.launch(vm.suggestedName("xlsx")) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Save as CSV") },
                                        onClick = { saveMenu = false; saveCsv.launch(vm.suggestedName("csv")) }
                                    )
                                } else {
                                    DropdownMenuItem(
                                        text = { Text("Save as Word (.docx)") },
                                        onClick = { saveMenu = false; saveDocx.launch(vm.suggestedName("docx")) }
                                    )
                                }
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { newMenu = true }) { Icon(Icons.Filled.Add, "New file") }
                        DropdownMenu(expanded = newMenu, onDismissRequest = { newMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("New spreadsheet") },
                                onClick = { newMenu = false; vm.newSheet() }
                            )
                            DropdownMenuItem(
                                text = { Text("New document") },
                                onClick = { newMenu = false; vm.newDocument() }
                            )
                        }
                    }
                    IconButton(onClick = { openDoc() }) { Icon(Icons.Filled.FolderOpen, "Open document") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
            when (st) {
                DocState.Idle -> EmptyState(
                    Icons.Filled.Description,
                    "No document open",
                    "Open an Excel (.xlsx), CSV or Word (.docx) file, or tap + to create a new spreadsheet or document.",
                    "Open document"
                ) { openDoc() }
                DocState.Loading -> CircularProgressIndicator()
                is DocState.Error -> EmptyState(Icons.Filled.Error, "Can't open file", st.message, "Choose another file") { openDoc() }
                is DocState.Loaded -> {
                    if (isTable) SheetEditor(vm, st.note) else WordEditor(vm, st.note)
                }
            }
        }
    }
}

@Composable
private fun Banner(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSecondaryContainer,
        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.secondaryContainer).padding(10.dp)
    )
}

// ===================== Excel-style sheet =====================

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SheetEditor(vm: DocsViewModel, note: String?) {
    val rows = vm.rows
    val ev = remember(rows) { SheetEvaluator(rows) }
    val cols = (rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
    var selR by remember { mutableIntStateOf(0) }
    var selC by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    val cw = 120
    val rn = 44
    val line = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

    Column(Modifier.fillMaxSize()) {
        Banner(
            (note?.let { "$it " } ?: "") +
                "Tap a cell to edit. Type = to enter a formula, e.g. =SUM(A1:A5). Saving creates a new copy."
        )
        Row(
            Modifier.fillMaxWidth().clickable { editing = true }.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("fx", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(
                colName(selC) + (selR + 1) + ":  " + ev.raw(selR, selC),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth().horizontalScroll(rememberScrollState())) {
            LazyColumn(Modifier.width((rn + cw * cols).dp).fillMaxHeight()) {
                stickyHeader {
                    Row(Modifier.background(MaterialTheme.colorScheme.primaryContainer)) {
                        Box(Modifier.width(rn.dp).height(36.dp))
                        for (c in 0 until cols) {
                            Box(
                                Modifier.width(cw.dp).height(36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    colName(c),
                                    fontWeight = FontWeight.Bold,
                                    color = if (c == selC) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
                itemsIndexed(rows) { r, _ ->
                    Row {
                        Box(
                            Modifier.width(rn.dp).height(40.dp).background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) { Text("${r + 1}", style = MaterialTheme.typography.labelMedium) }
                        for (c in 0 until cols) {
                            val selected = r == selR && c == selC
                            val shown = ev.display(r, c)
                            val numberLike = shown.isNotEmpty() &&
                                (shown[0].isDigit() || (shown[0] == '-' && shown.length > 1 && shown[1].isDigit()))
                            val isError = ev.isFormula(r, c) && shown.startsWith("#")
                            Box(
                                Modifier.width(cw.dp).height(40.dp)
                                    .border(0.5.dp, line)
                                    .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary) else Modifier)
                                    .clickable { selR = r; selC = c; editing = true }
                                    .padding(horizontal = 8.dp),
                                contentAlignment = if (numberLike) Alignment.CenterEnd else Alignment.CenterStart
                            ) {
                                Text(
                                    shown,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AssistChip(onClick = { vm.addRow(selR) }, label = { Text("+ Row") })
            AssistChip(onClick = { vm.addColumn(selC) }, label = { Text("+ Column") })
            AssistChip(onClick = {
                vm.deleteRow(selR)
                selR = selR.coerceAtMost((vm.rows.size - 1).coerceAtLeast(0))
            }, label = { Text("Delete row") })
            AssistChip(onClick = {
                vm.deleteColumn(selC)
                val nc = (vm.rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
                selC = selC.coerceAtMost(nc - 1)
            }, label = { Text("Delete column") })
        }
    }

    if (editing) {
        CellDialog(
            label = colName(selC) + (selR + 1),
            initial = ev.raw(selR, selC),
            onSave = { vm.setCell(selR, selC, it); editing = false },
            onDismiss = { editing = false }
        )
    }
}

@Composable
private fun CellDialog(label: String, initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit cell $label") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 6,
                    placeholder = { Text("Value or =formula") }
                )
                Text(
                    "Formulas start with =  (e.g. =A1+B1, =IF(A1>10,\"High\",\"Low\"))",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("SUM", "AVERAGE", "MIN", "MAX", "COUNT", "IF", "ROUND", "VLOOKUP").forEach { fn ->
                        AssistChip(
                            onClick = { text = (if (text.startsWith("=")) text else "=") + fn + "(" },
                            label = { Text(fn) }
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ===================== Word-style editor =====================

@Composable
private fun WordEditor(vm: DocsViewModel, note: String?) {
    val paras = vm.paras
    var sel by remember { mutableIntStateOf(0) }
    val cur = paras.getOrNull(sel)
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface

    Column(Modifier.fillMaxSize()) {
        Banner(
            (note?.let { "$it " } ?: "") +
                "Tap a paragraph to edit it, then use the toolbar to format that paragraph. Saving creates a new .docx copy."
        )
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
            itemsIndexed(paras) { i, p ->
                val size = when (p.style) {
                    1 -> 26.sp
                    2 -> 20.sp
                    else -> 16.sp
                }
                BasicTextField(
                    value = p.text,
                    onValueChange = { vm.setParaText(i, it) },
                    textStyle = TextStyle(
                        fontSize = size,
                        fontWeight = if (p.bold || p.style > 0) FontWeight.Bold else FontWeight.Normal,
                        fontStyle = if (p.italic) FontStyle.Italic else FontStyle.Normal,
                        textAlign = when (p.align) {
                            1 -> TextAlign.Center
                            2 -> TextAlign.End
                            else -> TextAlign.Start
                        },
                        color = onSurface
                    ),
                    cursorBrush = SolidColor(primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .then(
                            if (i == sel) Modifier.border(1.dp, primary.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            else Modifier
                        )
                        .padding(6.dp)
                        .onFocusChanged { if (it.isFocused) sel = i },
                    decorationBox = { inner ->
                        Row {
                            if (p.bullet) Text("•  ", fontSize = size, color = onSurface)
                            Box(Modifier.weight(1f)) {
                                if (p.text.isEmpty()) {
                                    Text("Type here…", fontSize = size, color = MaterialTheme.colorScheme.outline)
                                }
                                inner()
                            }
                        }
                    }
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = cur?.bold == true, onClick = { vm.updatePara(sel) { it.copy(bold = !it.bold) } }, label = { Text("Bold") })
            FilterChip(selected = cur?.italic == true, onClick = { vm.updatePara(sel) { it.copy(italic = !it.italic) } }, label = { Text("Italic") })
            FilterChip(selected = cur?.style == 1, onClick = { vm.updatePara(sel) { it.copy(style = if (it.style == 1) 0 else 1) } }, label = { Text("Heading 1") })
            FilterChip(selected = cur?.style == 2, onClick = { vm.updatePara(sel) { it.copy(style = if (it.style == 2) 0 else 2) } }, label = { Text("Heading 2") })
            FilterChip(selected = cur?.bullet == true, onClick = { vm.updatePara(sel) { it.copy(bullet = !it.bullet) } }, label = { Text("Bullet") })
            FilterChip(selected = cur?.align == 0, onClick = { vm.updatePara(sel) { it.copy(align = 0) } }, label = { Text("Left") })
            FilterChip(selected = cur?.align == 1, onClick = { vm.updatePara(sel) { it.copy(align = 1) } }, label = { Text("Center") })
            FilterChip(selected = cur?.align == 2, onClick = { vm.updatePara(sel) { it.copy(align = 2) } }, label = { Text("Right") })
            AssistChip(onClick = { vm.addPara(sel); sel += 1 }, label = { Text("+ Paragraph") })
            AssistChip(onClick = {
                vm.deletePara(sel)
                sel = sel.coerceAtMost((vm.paras.size - 1).coerceAtLeast(0))
            }, label = { Text("Delete paragraph") })
        }
    }
}
