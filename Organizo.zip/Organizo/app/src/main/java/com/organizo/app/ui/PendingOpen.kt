package com.organizo.app.ui

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** A file that arrived from outside (WhatsApp "Open with" / "Share"), waiting to be opened by a screen. */
object PendingOpen {
    var uri by mutableStateOf<Uri?>(null)
    var kind by mutableStateOf("")
}
