package com.organizo.app.viewmodel

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class FormulaException(val code: String) : Exception(code)
class FErr(val code: String)

internal class RangeVal(val values: List<Any>, val rows: Int, val cols: Int)

internal sealed class Node
internal class NumN(val v: Double) : Node()
internal class StrN(val v: String) : Node()
internal class BoolN(val v: Boolean) : Node()
internal class RefN(val r: Int, val c: Int) : Node()
internal class RangeN(val r1: Int, val c1: Int, val r2: Int, val c2: Int) : Node()
internal class BinN(val op: String, val l: Node, val r: Node) : Node()
internal class UnN(val op: Char, val n: Node) : Node()
internal class CallN(val name: String, val args: List<Node>) : Node()

val SUPPORTED_FUNCTIONS = setOf(
    "SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNTA", "PRODUCT", "MEDIAN",
    "ROUND", "ROUNDUP", "ROUNDDOWN", "ABS", "SQRT", "POWER", "MOD", "INT", "PI",
    "IF", "IFERROR", "AND", "OR", "NOT",
    "CONCATENATE", "CONCAT", "LEN", "UPPER", "LOWER", "TRIM", "LEFT", "RIGHT", "MID",
    "VLOOKUP", "SUMIF", "COUNTIF"
)

private val numRegex = Regex("^[-+]?([0-9]+(\\.[0-9]*)?|\\.[0-9]+)([eE][-+]?[0-9]+)?$")
private val refRegex = Regex("^\\$?([A-Za-z]{1,3})\\$?([0-9]+)$")

fun formatNumber(d: Double): String {
    if (d.isNaN() || d.isInfinite()) return "#NUM!"
    return BigDecimal(d).round(MathContext(12)).stripTrailingZeros().toPlainString()
}

private fun colLettersToIndex(s: String): Int {
    var n = 0
    for (ch in s.uppercase()) n = n * 26 + (ch - 'A' + 1)
    return n - 1
}

/** True when every function used is one we can calculate (otherwise the cached value is kept). */
fun isSupportedFormula(f: String): Boolean {
    if (f.contains('!') || f.contains('[') || f.contains('{')) return false
    for (m in Regex("([A-Za-z_][A-Za-z0-9_.]*)\\(").findAll(f)) {
        if (m.groupValues[1].uppercase() !in SUPPORTED_FUNCTIONS) return false
    }
    return try {
        FParser(f).parseAll()
        true
    } catch (e: FormulaException) {
        false
    }
}

internal class FParser(private val s: String) {
    private var i = 0

    private fun ws() {
        while (i < s.length && s[i].isWhitespace()) i++
    }

    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

    fun parseAll(): Node {
        val n = comparison()
        ws()
        if (i < s.length) throw FormulaException("#ERROR!")
        return n
    }

    private fun comparison(): Node {
        var l = concat()
        while (true) {
            ws()
            val op: String = when {
                s.startsWith("<=", i) -> "<="
                s.startsWith(">=", i) -> ">="
                s.startsWith("<>", i) -> "<>"
                peek() == '<' -> "<"
                peek() == '>' -> ">"
                peek() == '=' -> "="
                else -> return l
            }
            i += op.length
            l = BinN(op, l, concat())
        }
    }

    private fun concat(): Node {
        var l = additive()
        while (true) {
            ws()
            if (peek() == '&') {
                i++
                l = BinN("&", l, additive())
            } else return l
        }
    }

    private fun additive(): Node {
        var l = term()
        while (true) {
            ws()
            val c = peek()
            if (c == '+' || c == '-') {
                i++
                l = BinN(c.toString(), l, term())
            } else return l
        }
    }

    private fun term(): Node {
        var l = power()
        while (true) {
            ws()
            val c = peek()
            if (c == '*' || c == '/') {
                i++
                l = BinN(c.toString(), l, power())
            } else return l
        }
    }

    private fun power(): Node {
        var l = unary()
        while (true) {
            ws()
            if (peek() == '^') {
                i++
                l = BinN("^", l, unary())
            } else return l
        }
    }

    private fun unary(): Node {
        ws()
        val c = peek()
        if (c == '-') {
            i++
            return UnN('-', unary())
        }
        if (c == '+') {
            i++
            return unary()
        }
        return postfix()
    }

    private fun postfix(): Node {
        var n = primary()
        while (true) {
            ws()
            if (peek() == '%') {
                i++
                n = UnN('%', n)
            } else return n
        }
    }

    private fun ident(): String {
        val st = i
        while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '$' || s[i] == '_' || s[i] == '.')) i++
        return s.substring(st, i)
    }

    private fun primary(): Node {
        ws()
        val c = peek()
        if (c == '(') {
            i++
            val n = comparison()
            ws()
            if (peek() != ')') throw FormulaException("#ERROR!")
            i++
            return n
        }
        if (c == '"') {
            i++
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw FormulaException("#ERROR!")
                val ch = s[i]
                if (ch == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') {
                        sb.append('"')
                        i += 2
                    } else {
                        i++
                        break
                    }
                } else {
                    sb.append(ch)
                    i++
                }
            }
            return StrN(sb.toString())
        }
        if (c.isDigit() || c == '.') {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                val save = i
                i++
                if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
                if (i < s.length && s[i].isDigit()) {
                    while (i < s.length && s[i].isDigit()) i++
                } else {
                    i = save
                }
            }
            return NumN(s.substring(st, i).toDoubleOrNull() ?: throw FormulaException("#ERROR!"))
        }
        if (c.isLetter() || c == '$' || c == '_') {
            val name = ident()
            if (peek() == '(') {
                i++
                val args = mutableListOf<Node>()
                ws()
                if (peek() == ')') {
                    i++
                } else {
                    while (true) {
                        args.add(comparison())
                        ws()
                        val d = peek()
                        if (d == ',' || d == ';') {
                            i++
                        } else if (d == ')') {
                            i++
                            break
                        } else throw FormulaException("#ERROR!")
                    }
                }
                return CallN(name.uppercase(), args)
            }
            val up = name.uppercase()
            if (up == "TRUE") return BoolN(true)
            if (up == "FALSE") return BoolN(false)
            val m1 = refRegex.matchEntire(name) ?: throw FormulaException("#NAME?")
            val r1 = (m1.groupValues[2].toIntOrNull() ?: throw FormulaException("#REF!")) - 1
            val c1 = colLettersToIndex(m1.groupValues[1])
            if (r1 < 0) throw FormulaException("#REF!")
            if (peek() == ':') {
                i++
                val n2 = ident()
                val m2 = refRegex.matchEntire(n2) ?: throw FormulaException("#ERROR!")
                val r2 = (m2.groupValues[2].toIntOrNull() ?: throw FormulaException("#REF!")) - 1
                val c2 = colLettersToIndex(m2.groupValues[1])
                if (r2 < 0) throw FormulaException("#REF!")
                return RangeN(minOf(r1, r2), minOf(c1, c2), maxOf(r1, r2), maxOf(c1, c2))
            }
            return RefN(r1, c1)
        }
        throw FormulaException("#ERROR!")
    }
}

/** Calculates the cells of one sheet. Raw cell text starting with "=" is a formula. */
class SheetEvaluator(private val rows: List<List<String>>) {
    private val cache = HashMap<Long, Any>()
    private val active = HashSet<Long>()
    private val dataCols = rows.maxOfOrNull { it.size } ?: 0

    private fun key(r: Int, c: Int): Long = r.toLong() * 100000L + c

    fun raw(r: Int, c: Int): String = rows.getOrNull(r)?.getOrNull(c) ?: ""

    fun isFormula(r: Int, c: Int): Boolean {
        val t = raw(r, c)
        return t.length > 1 && t[0] == '='
    }

    /** Double, String, Boolean or FErr. */
    fun cellValue(r: Int, c: Int): Any {
        val k = key(r, c)
        val hit = cache[k]
        if (hit != null) return hit
        val text = raw(r, c)
        val v: Any = if (text.length > 1 && text[0] == '=') {
            if (!active.add(k)) return FErr("#CIRC!")
            try {
                scalar(eval(FParser(text.substring(1)).parseAll()))
            } catch (e: FormulaException) {
                FErr(e.code)
            } catch (e: StackOverflowError) {
                FErr("#ERROR!")
            } finally {
                active.remove(k)
            }
        } else if (numRegex.matches(text.trim())) {
            text.trim().toDouble()
        } else {
            text
        }
        cache[k] = v
        return v
    }

    fun display(r: Int, c: Int): String {
        if (!isFormula(r, c)) return raw(r, c)
        return format(cellValue(r, c))
    }

    fun format(v: Any): String = when (v) {
        is Double -> formatNumber(v)
        is Boolean -> if (v) "TRUE" else "FALSE"
        is FErr -> v.code
        is String -> v
        else -> ""
    }

    // ---------- evaluation ----------
    private fun scalar(v: Any): Any {
        if (v is RangeVal) {
            if (v.values.size == 1) return v.values[0]
            throw FormulaException("#VALUE!")
        }
        return v
    }

    private fun num(v: Any): Double = when (v) {
        is Double -> v
        is Boolean -> if (v) 1.0 else 0.0
        is String -> {
            val t = v.trim()
            if (t.isEmpty()) 0.0 else if (numRegex.matches(t)) t.toDouble() else throw FormulaException("#VALUE!")
        }
        is RangeVal -> num(scalar(v))
        else -> throw FormulaException("#VALUE!")
    }

    private fun text(v: Any): String = when (v) {
        is Double -> formatNumber(v)
        is Boolean -> if (v) "TRUE" else "FALSE"
        is String -> v
        is RangeVal -> text(scalar(v))
        else -> ""
    }

    private fun truthy(v: Any): Boolean = when (v) {
        is Boolean -> v
        is Double -> v != 0.0
        is String -> {
            if (v.equals("TRUE", true)) true
            else if (v.equals("FALSE", true) || v.isEmpty()) false
            else throw FormulaException("#VALUE!")
        }
        else -> throw FormulaException("#VALUE!")
    }

    private fun eval(n: Node): Any = when (n) {
        is NumN -> n.v
        is StrN -> n.v
        is BoolN -> n.v
        is RefN -> {
            val v = cellValue(n.r, n.c)
            if (v is FErr) throw FormulaException(v.code)
            v
        }
        is RangeN -> rangeVal(n)
        is UnN -> if (n.op == '-') -num(eval(n.n)) else num(eval(n.n)) / 100.0
        is BinN -> binary(n)
        is CallN -> call(n)
    }

    private fun rangeVal(n: RangeN): RangeVal {
        val rs = n.r2 - n.r1 + 1
        val cs = n.c2 - n.c1 + 1
        if (rs.toLong() * cs > 200000L) throw FormulaException("#VALUE!")
        val out = ArrayList<Any>(rs * cs)
        for (r in n.r1..n.r2) {
            for (c in n.c1..n.c2) {
                if (r < rows.size && c < dataCols) {
                    val v = cellValue(r, c)
                    if (v is FErr) throw FormulaException(v.code)
                    out.add(v)
                } else out.add("")
            }
        }
        return RangeVal(out, rs, cs)
    }

    private fun binary(n: BinN): Any {
        val l = scalar(eval(n.l))
        val r = scalar(eval(n.r))
        return when (n.op) {
            "+" -> num(l) + num(r)
            "-" -> num(l) - num(r)
            "*" -> num(l) * num(r)
            "/" -> {
                val d = num(r)
                if (d == 0.0) throw FormulaException("#DIV/0!")
                num(l) / d
            }
            "^" -> {
                val p = Math.pow(num(l), num(r))
                if (p.isNaN() || p.isInfinite()) throw FormulaException("#NUM!")
                p
            }
            "&" -> text(l) + text(r)
            else -> compare(n.op, l, r)
        }
    }

    private fun compare(op: String, a: Any, b: Any): Boolean {
        var l = a
        var r = b
        if (l is String && l.isEmpty() && r is Double) l = 0.0
        if (r is String && r.isEmpty() && l is Double) r = 0.0
        val cmp: Int = if (l is Double && r is Double) {
            if (l < r) -1 else if (l > r) 1 else 0
        } else if (l is Boolean && r is Boolean) {
            l.compareTo(r)
        } else if (l is Double) {
            -1
        } else if (r is Double) {
            1
        } else {
            text(l).compareTo(text(r), ignoreCase = true)
        }
        return when (op) {
            "=" -> cmp == 0
            "<>" -> cmp != 0
            "<" -> cmp < 0
            ">" -> cmp > 0
            "<=" -> cmp <= 0
            else -> cmp >= 0
        }
    }

    private fun nums(args: List<Node>): List<Double> {
        val out = mutableListOf<Double>()
        for (a in args) {
            val v = eval(a)
            if (v is RangeVal) {
                for (x in v.values) if (x is Double) out.add(x)
            } else out.add(num(v))
        }
        return out
    }

    private fun matches(cell: Any, crit: Any): Boolean {
        var op = "="
        var operand: Any = crit
        if (crit is String) {
            val m = Regex("^(<=|>=|<>|<|>|=)(.*)$").find(crit)
            if (m != null) {
                op = m.groupValues[1]
                val rest = m.groupValues[2].trim()
                operand = if (numRegex.matches(rest)) rest.toDouble() else m.groupValues[2]
            } else if (numRegex.matches(crit.trim())) {
                operand = crit.trim().toDouble()
            }
        }
        if (operand is Double && cell !is Double) return op == "<>"
        return compare(op, cell, operand)
    }

    private fun call(n: CallN): Any {
        val a = n.args
        fun need(min: Int, max: Int = min) {
            if (a.size < min || a.size > max) throw FormulaException("#ERROR!")
        }
        fun s(i: Int): Any = scalar(eval(a[i]))
        return when (n.name) {
            "SUM" -> nums(a).sum()
            "AVERAGE" -> {
                val x = nums(a)
                if (x.isEmpty()) throw FormulaException("#DIV/0!")
                x.sum() / x.size
            }
            "MIN" -> nums(a).minOrNull() ?: 0.0
            "MAX" -> nums(a).maxOrNull() ?: 0.0
            "PRODUCT" -> nums(a).fold(1.0) { acc, d -> acc * d }
            "MEDIAN" -> {
                val x = nums(a).sorted()
                if (x.isEmpty()) throw FormulaException("#NUM!")
                if (x.size % 2 == 1) x[x.size / 2] else (x[x.size / 2 - 1] + x[x.size / 2]) / 2.0
            }
            "COUNT" -> {
                var k = 0
                for (arg in a) {
                    val v = eval(arg)
                    if (v is RangeVal) k += v.values.count { it is Double } else if (v is Double) k++
                }
                k.toDouble()
            }
            "COUNTA" -> {
                var k = 0
                for (arg in a) {
                    val v = eval(arg)
                    if (v is RangeVal) k += v.values.count { !(it is String && it.isEmpty()) } else k++
                }
                k.toDouble()
            }
            "ABS" -> {
                need(1)
                Math.abs(num(s(0)))
            }
            "SQRT" -> {
                need(1)
                val x = num(s(0))
                if (x < 0) throw FormulaException("#NUM!")
                Math.sqrt(x)
            }
            "POWER" -> {
                need(2)
                val p = Math.pow(num(s(0)), num(s(1)))
                if (p.isNaN() || p.isInfinite()) throw FormulaException("#NUM!")
                p
            }
            "MOD" -> {
                need(2)
                val x = num(s(0))
                val d = num(s(1))
                if (d == 0.0) throw FormulaException("#DIV/0!")
                x - d * Math.floor(x / d)
            }
            "INT" -> {
                need(1)
                Math.floor(num(s(0)))
            }
            "PI" -> Math.PI
            "ROUND", "ROUNDUP", "ROUNDDOWN" -> {
                need(1, 2)
                val x = num(s(0))
                val d = if (a.size == 2) num(s(1)).toInt() else 0
                if (x.isNaN() || x.isInfinite()) throw FormulaException("#NUM!")
                val mode = when (n.name) {
                    "ROUND" -> RoundingMode.HALF_UP
                    "ROUNDUP" -> RoundingMode.UP
                    else -> RoundingMode.DOWN
                }
                BigDecimal.valueOf(x).setScale(d, mode).toDouble()
            }
            "IF" -> {
                need(2, 3)
                if (truthy(s(0))) s(1) else if (a.size == 3) s(2) else false
            }
            "IFERROR" -> {
                need(2)
                try {
                    s(0)
                } catch (e: FormulaException) {
                    s(1)
                }
            }
            "AND", "OR" -> {
                val vals = mutableListOf<Boolean>()
                for (arg in a) {
                    val v = eval(arg)
                    if (v is RangeVal) {
                        for (x in v.values) {
                            if (x is Boolean) vals.add(x) else if (x is Double) vals.add(x != 0.0)
                        }
                    } else vals.add(truthy(v))
                }
                if (vals.isEmpty()) throw FormulaException("#VALUE!")
                if (n.name == "AND") vals.all { it } else vals.any { it }
            }
            "NOT" -> {
                need(1)
                !truthy(s(0))
            }
            "CONCATENATE", "CONCAT" -> {
                val sb = StringBuilder()
                for (arg in a) {
                    val v = eval(arg)
                    if (v is RangeVal) v.values.forEach { sb.append(text(it)) } else sb.append(text(v))
                }
                sb.toString()
            }
            "LEN" -> {
                need(1)
                text(s(0)).length.toDouble()
            }
            "UPPER" -> {
                need(1)
                text(s(0)).uppercase()
            }
            "LOWER" -> {
                need(1)
                text(s(0)).lowercase()
            }
            "TRIM" -> {
                need(1)
                text(s(0)).trim().replace(Regex(" +"), " ")
            }
            "LEFT", "RIGHT" -> {
                need(1, 2)
                val t = text(s(0))
                val k = if (a.size == 2) num(s(1)).toInt() else 1
                if (k < 0) throw FormulaException("#VALUE!")
                if (n.name == "LEFT") t.take(k) else t.takeLast(k)
            }
            "MID" -> {
                need(3)
                val t = text(s(0))
                val st = num(s(1)).toInt()
                val len = num(s(2)).toInt()
                if (st < 1 || len < 0) throw FormulaException("#VALUE!")
                if (st > t.length) "" else t.substring(st - 1, minOf(t.length, st - 1 + len))
            }
            "VLOOKUP" -> {
                need(3, 4)
                val keyV = s(0)
                val t = eval(a[1]) as? RangeVal ?: throw FormulaException("#VALUE!")
                val col = num(s(2)).toInt()
                if (col < 1 || col > t.cols) throw FormulaException("#REF!")
                val approx = if (a.size == 4) truthy(s(3)) else true
                var found = -1
                for (r in 0 until t.rows) {
                    val v = t.values[r * t.cols]
                    if (approx) {
                        if (compare("<=", v, keyV)) found = r else break
                    } else if (compare("=", v, keyV)) {
                        found = r
                        break
                    }
                }
                if (found < 0) throw FormulaException("#N/A")
                t.values[found * t.cols + col - 1]
            }
            "COUNTIF" -> {
                need(2)
                val rg = eval(a[0]) as? RangeVal ?: throw FormulaException("#VALUE!")
                val crit = s(1)
                rg.values.count { matches(it, crit) }.toDouble()
            }
            "SUMIF" -> {
                need(2, 3)
                val rg = eval(a[0]) as? RangeVal ?: throw FormulaException("#VALUE!")
                val crit = s(1)
                val sumRg = if (a.size == 3) (eval(a[2]) as? RangeVal ?: throw FormulaException("#VALUE!")) else rg
                var total = 0.0
                for (idx in rg.values.indices) {
                    if (matches(rg.values[idx], crit)) {
                        val x = sumRg.values.getOrNull(idx)
                        if (x is Double) total += x
                    }
                }
                total
            }
            else -> throw FormulaException("#NAME?")
        }
    }
}
