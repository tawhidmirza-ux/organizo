package com.organizo.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val pinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis(),
    val color: Int = 0,
    val category: String = ""
)

/** priority: 0 = Low, 1 = Medium, 2 = High. dueDate = LocalDate epoch day (no time zone issues). */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val priority: Int = 1,
    val dueDate: Long? = null,
    val completed: Boolean = false,
    /** 0 = Pending, 1 = In Progress, 2 = Completed (completed is kept in sync with status == 2). */
    val status: Int = 0,
    val category: String = "",
    val carried: Int = 0
)

@Dao
interface NoteDao {
    @Query(
        "SELECT * FROM notes WHERE title LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' " +
            "ORDER BY pinned DESC, updatedAt DESC"
    )
    fun search(q: String): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun get(id: Long): Note?

    @Insert
    suspend fun insert(note: Note): Long

    @Update
    suspend fun update(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE notes SET pinned = :pinned WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean)

    @Query("SELECT COUNT(*) FROM notes")
    fun count(): Flow<Int>

    @Query("SELECT * FROM notes")
    suspend fun snapshot(): List<Note>

    @Query("DELETE FROM notes")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<Note>)
}

@Dao
interface TaskDao {
    @Query(
        "SELECT * FROM tasks ORDER BY completed ASC, " +
            "CASE WHEN dueDate IS NULL THEN 1 ELSE 0 END, dueDate ASC, priority DESC"
    )
    fun all(): Flow<List<Task>>

    @Insert
    suspend fun insert(task: Task): Long

    @Update
    suspend fun update(task: Task)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM tasks WHERE status != 2")
    fun pendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE status != 2 AND dueDate IS NOT NULL AND dueDate < :today")
    fun overdueCount(today: Long): Flow<Int>

    @Query(
        "UPDATE tasks SET dueDate = :today, carried = carried + 1 " +
            "WHERE status != 2 AND dueDate IS NOT NULL AND dueDate < :today"
    )
    suspend fun carryForward(today: Long): Int

    @Query("SELECT * FROM tasks")
    suspend fun snapshot(): List<Task>

    @Query("DELETE FROM tasks")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<Task>)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE notes ADD COLUMN color INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE notes ADD COLUMN category TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE tasks ADD COLUMN status INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE tasks ADD COLUMN category TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE tasks ADD COLUMN carried INTEGER NOT NULL DEFAULT 0")
        db.execSQL("UPDATE tasks SET status = 2 WHERE completed = 1")
    }
}

@Database(entities = [Note::class, Task::class], version = 2, exportSchema = false)
abstract class OrganizoDb : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile private var instance: OrganizoDb? = null

        fun get(context: Context): OrganizoDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, OrganizoDb::class.java, "organizo.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}

/** Theme mode: 0 = system, 1 = light, 2 = dark. */
class SettingsStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("organizo_settings", Context.MODE_PRIVATE)
    private val _mode = MutableStateFlow(prefs.getInt("theme_mode", 0))
    val mode: StateFlow<Int> = _mode.asStateFlow()

    fun setMode(m: Int) {
        prefs.edit().putInt("theme_mode", m).apply()
        _mode.value = m
    }

    companion object {
        @Volatile private var instance: SettingsStore? = null

        fun get(context: Context): SettingsStore = instance ?: synchronized(this) {
            instance ?: SettingsStore(context.applicationContext).also { instance = it }
        }
    }
}
