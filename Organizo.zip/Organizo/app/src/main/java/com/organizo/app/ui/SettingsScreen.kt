package com.organizo.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.organizo.app.data.SettingsStore
import com.organizo.app.viewmodel.BackupViewModel
import java.time.LocalDate

@Composable
fun SettingsScreen(bvm: BackupViewModel = viewModel()) {
    val ctx = LocalContext.current
    val store = remember { SettingsStore.get(ctx) }
    val mode by store.mode.collectAsState()
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
    }
    val snack = remember { SnackbarHostState() }
    var confirmRestore by remember { mutableStateOf(false) }

    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) bvm.export(uri)
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) bvm.import(uri)
    }
    LaunchedEffect(bvm.message) {
        val m = bvm.message
        if (m != null) {
            snack.showSnackbar(m)
            bvm.clearMessage()
        }
    }

    Scaffold(
        topBar = { OrgTopBar("Settings") },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionTitle("Appearance")
            Card(shape = RoundedCornerShape(16.dp), colors = orgCardColors(), elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.padding(vertical = 4.dp)) {
                    listOf("System default", "Light mode", "Dark mode").forEachIndexed { i, label ->
                        Row(
                            Modifier.fillMaxWidth().clickable { store.setMode(i) }.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = mode == i, onClick = { store.setMode(i) })
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            SectionTitle("Backup & restore")
            Card(shape = RoundedCornerShape(16.dp), colors = orgCardColors(), elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Save all notes and tasks to one file. In the file picker choose Google Drive (or any cloud app) to keep a copy online, or choose phone storage for an offline copy.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { backupPicker.launch("organizo_backup_" + LocalDate.now() + ".json") },
                        enabled = !bvm.busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CloudUpload, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Back up now")
                    }
                    OutlinedButton(
                        onClick = { confirmRestore = true },
                        enabled = !bvm.busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CloudDownload, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Restore from backup")
                    }
                    Text(
                        "Android's own automatic Google backup may also protect app data if it is switched on in your phone's settings.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionTitle("About")
            Card(shape = RoundedCornerShape(16.dp), colors = orgCardColors(), elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    InfoRow("App", "Organizo")
                    InfoRow("Version", version)
                    InfoRow("Package", ctx.packageName)
                    InfoRow("Storage", "Notes and tasks are stored on this device. Organizo works fully offline.")
                }
            }
        }
    }

    if (confirmRestore) {
        ConfirmDialog(
            title = "Restore from backup?",
            message = "This replaces all current notes and tasks with the ones in the backup file.",
            confirmLabel = "Choose file",
            onConfirm = {
                confirmRestore = false
                restorePicker.launch(arrayOf("application/json", "*/*"))
            },
            onDismiss = { confirmRestore = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
